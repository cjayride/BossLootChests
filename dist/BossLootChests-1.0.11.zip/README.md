# Boss Loot Chests

When a **boss** dies, its loot is placed in black-metal chests at its feet instead of dumping on the ground.

That stops auto-pickup and crowded melee from grabbing coins and unique drops before anyone sees what dropped.

Install on **server and all clients**.

## What it does

- Intercepts boss loot before it becomes a world item drop.
- Fills `piece_chest_blackmetal` chests (config: `ChestPrefab`). Spawns more chests if one is full.
- Chests cannot be broken or hammered away.
- An emptied chest deletes itself and plays a smoke puff.
- Works with EpicLoot: magic items go into the chests too.
- Drop That and Epic Loot roll first, so magic weapons keep their rolls in the chest.
- One-per-player drops count only players within `PerPlayerRange` of the boss when it dies. Drops with an amount range (such as Coins 200–300) give that amount for each of those players.
- Adds that were within `AddRadius` of the boss while it was alive still drop into the boss chest after it dies, for as long as you take to finish them. Creatures that show up after the boss is dead stay on the ground. An add nobody is fighting is forgotten after `AddIdleSeconds`. Nearby adds that die within `AddSeconds` of the chest appearing also go in. This works in multiplayer, whichever player's game handles the add.

## Config (`cjayride.bosslootchests.cfg`)

| Setting | Default | |
|---|---|---|
| `Enabled` | true | Master switch |
| `ChestPrefab` | piece_chest_blackmetal | World container prefab |
| `RemoveSmoke` | true | Smoke when an empty chest vanishes |
| `AddRadius` | 180 | Meters around a boss in combat. Add drops in that range go into the boss chest. |
| `AddSeconds` | 60 | Seconds after the boss chest appears that nearby add drops still go into it. |
| `AddIdleSeconds` | 1200 | After the boss dies, an add that nobody is fighting is forgotten after this many seconds. Fighting it resets the timer. |
| `PerPlayerAmounts` | true | One-per-player boss drops count nearby players. Amount ranges are given per player. |
| `PerPlayerRange` | 400 | Meters from the boss. Only players this close when it dies count for one-per-player drops. |
| `BountyLootInChest` | false | Epic Loot bounty targets use boss chests too. |

## Changelog

See `CHANGELOG.md`.
